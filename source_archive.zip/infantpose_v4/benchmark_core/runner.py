from pathlib import Path
from datetime import datetime, timezone
import json, platform, statistics, uuid
from .contracts import Prediction, RunManifest
from .data import load_handoff, sha256

FAIR_REFERENCE={'batch_size':1,'warmup_images':10,'precision':'fp32','amp':False,'compile':False,'quantization':False,'tensor_rt':False,'rankable_across_models':True}
from .metrics import score, summarise

def _write_jsonl(path, rows):
    with open(path,'w',encoding='utf-8') as f:
        for r in rows: f.write(json.dumps(r,ensure_ascii=False)+'\n')
def run_dataset(adapter, handoff_root, output_root, profile, protocol):
    if profile!='fair_reference': raise RuntimeError('正式專案只寫入 fair_reference；原生加速結果不可混入。')
    bad={k:(protocol.get(k),v) for k,v in FAIR_REFERENCE.items() if protocol.get(k)!=v}
    if bad: raise RuntimeError(f'fair_reference 協定被更動：{bad}')
    manifest, rows=load_handoff(handoff_root); run_id=f'{adapter.model_id}_{manifest["dataset_id"]}_{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}_{uuid.uuid4().hex[:6]}'
    adapter.load(profile); adapter.warmup(rows[:10],profile)
    predictions=[]; metrics=[]
    for row in rows:
        try: p=adapter.predict(row,profile)
        except Exception as e: p=Prediction(row['sample_id'],manifest['dataset_id'],adapter.model_id,run_id,'model_error',error_code=type(e).__name__,native={'message':str(e)[:1000]},timings_ms={'decode':0.0,'preprocess':0.0,'inference':0.0,'postprocess':0.0,'end_to_end':0.0})
        p.run_id=run_id; p.validate(); predictions.append(p.record()); metrics.append(score(row,p))
    timing=[p.get('timings_ms',{}).get('end_to_end') for p in predictions]; timing=[x for x in timing if x is not None]
    summary=summarise(metrics); summary['latency_ms']={'n':len(timing),'mean':sum(timing)/len(timing) if timing else None,'median':statistics.median(timing) if timing else None,'p95':sorted(timing)[max(0,int(.95*len(timing))-1)] if timing else None}
    out=Path(output_root)/adapter.model_id/manifest['dataset_id']/profile/run_id; out.mkdir(parents=True)
    env={'platform':platform.platform(),'python':platform.python_version()}
    try:
        import torch
        env.update(torch=torch.__version__,cuda_available=torch.cuda.is_available(),gpu=torch.cuda.get_device_name(0) if torch.cuda.is_available() else None)
    except Exception: pass
    rm=RunManifest('InfantPose-Bench-v4','v4.run',run_id,manifest['dataset_id'],adapter.model_id,profile,sha256(Path(handoff_root)/'dataset_manifest.json'),adapter.provenance(),env,protocol,{'input':len(rows),'ok':len([p for p in predictions if p['status']=='ok']),'no_detection':len([p for p in predictions if p['status']=='no_detection']),'errors':len([p for p in predictions if p['status'] in ('model_error','input_error','mapping_error')])},summary).record()
    rm.update({'data_handoff_hash':manifest['index_sha256'],'weight_source':adapter.provenance().get('weight_source'),'timing_comparability':True,'timing_scope':'decode + preprocessing + inference + postprocessing','warmup':{'images':10,'excluded_from_metrics':True},'profile_id':'fair_reference_v1'})
    (out/'run_manifest.json').write_text(json.dumps(rm,indent=2),encoding='utf-8'); _write_jsonl(out/'predictions.jsonl',predictions); _write_jsonl(out/'metrics.jsonl',metrics); return out
