from abc import ABC, abstractmethod
from time import perf_counter
class BaseAdapter(ABC):
    model_id='unset'
    def load(self,profile): pass
    def warmup(self,rows,profile):
        for row in rows: self.predict(row,profile)
    @abstractmethod
    def predict(self,row,profile): ...
    def provenance(self): return {'model_id':self.model_id,'adapter':type(self).__name__}
    @staticmethod
    def clock(fn):
        t=perf_counter(); result=fn(); return result,(perf_counter()-t)*1000
