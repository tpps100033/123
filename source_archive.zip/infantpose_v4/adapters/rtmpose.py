from time import perf_counter
import numpy as np
from .base import BaseAdapter
from benchmark_core.contracts import Prediction

class RTMPoseM(BaseAdapter):
    model_id='rtmpose_m'
    def load(self,profile):
        from mmpose.apis import MMPoseInferencer
        self.inferencer=MMPoseInferencer(pose2d='rtmpose-m',device='cuda:0')
    def predict(self,row,profile):
        from PIL import Image
        started=perf_counter(); t=perf_counter(); rgb=np.asarray(Image.open(row['image_path']).convert('RGB')); decode=(perf_counter()-t)*1000
        t=perf_counter(); result=next(self.inferencer(rgb,return_vis=False,show=False)); inf=(perf_counter()-t)*1000; t=perf_counter(); people=result.get('predictions',[[]])[0]
        timing={'decode':decode,'preprocess':0.,'inference':inf,'postprocess':0.,'end_to_end':0.}
        if not people:
            timing['postprocess']=(perf_counter()-t)*1000; timing['end_to_end']=(perf_counter()-started)*1000
            return Prediction(row['sample_id'],row['dataset_id'],self.model_id,'','no_detection',timings_ms=timing,error_code='NO_DETECTION',native=result)
        person=max(people,key=lambda p:float(p.get('bbox_score',0.))); pts=np.asarray(person['keypoints'],dtype=float).tolist(); scores=np.asarray(person.get('keypoint_scores',[1]*17),dtype=float).tolist()
        timing['postprocess']=(perf_counter()-t)*1000; timing['end_to_end']=(perf_counter()-started)*1000
        return Prediction(row['sample_id'],row['dataset_id'],self.model_id,'','ok',pts,scores,timings_ms=timing,native=person)
    def provenance(self): return {'model_id':self.model_id,'adapter':type(self).__name__,'weight_source':'MMPose official model hub: rtmpose-m','amp':False,'compile':False,'quantization':False,'tensorrt':False}
