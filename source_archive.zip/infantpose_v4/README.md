# InfantPose-Bench v4

此版本是唯一正式專案。研究問題限定為：**通用成人姿態模型在嬰兒靜態影像上的零樣本跨年齡泛化**。

## 固定範圍

| 類別 | 固定內容 |
|---|---|
| 成人基準 | COCO SinglePerson val2017，921 張、COCO-17 |
| 嬰兒跨域 | SyRIP Test100，100 張、經驗證的 COCO-17 對應 |
| 模型 | MediaPipe Pose Heavy、MoveNet Thunder、RTMPose-M、YOLO11x-Pose |
| 主實驗 | `fair_reference`：batch=1、固定 10 張 warm-up、FP32、禁止 AMP／compile／量化／TensorRT；decode、前處理、推論與後處理均納入端到端時間 |

## 不屬於 v4 的項目

成人／嬰兒睡眠資料集、Roboflow、SLP、影片、睡姿分類、PPG、多模態融合、微調、Sapiens 與 OpenPose 不在此專案範圍。

## 結構

```
00_project_config/      凍結資料、模型、公平規格、core 與 adapters
01_notebooks/           Colab 操作入口（00、01–04、90、91）
02_datasets/            source_archives、canonical、model_cache
03_model_raw_outputs/   每筆原始預測與 run manifest
04_merged_results/      可比較 run 的合併表
05_analysis_results/    兩域主表與跨域下降
```

## 執行順序

1. `00_Prepare_TwoDomain_v4.ipynb`：唯一定義／產生資料 handoff 的 Notebook。
2. 執行 01–04 任一模型；每份 Notebook 只跑一個模型、兩個資料域、唯一的 fair_reference profile。
3. `90_Merge_v4.ipynb`：只讀取完成的 run package。
4. `91_Analysis_v4.ipynb`：只讀取 merge 結果，產生主表與跨域下降。

資料或標註不符合契約時，00 必須停止；不可用影像數量或推論成功率冒充姿態準確率。未偵測與錯誤在端到端 OKS/PCK 均為 0；條件式 OKS/PCK 與 coverage 必須分開報告。
